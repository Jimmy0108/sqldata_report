<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/foot.css">
    <title>網頁範例</title>
</head>
<body>
    <!-- 其他頁面內容 -->
    <footer class="footer">
        <div class="footter">
            <div class="footer-content">
                <p>&copy; NULL 網頁. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
