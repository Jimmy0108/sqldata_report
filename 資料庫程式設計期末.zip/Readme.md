1.此系統為電通大二資料庫程式設計課程之專案
2.需git到GITHUB上做版本控制# sqlProject
